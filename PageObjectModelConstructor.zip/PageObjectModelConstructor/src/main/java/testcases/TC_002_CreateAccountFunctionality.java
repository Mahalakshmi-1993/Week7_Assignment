package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_002_CreateAccountFunctionality extends ProjectSpecificMethods{
	@Test
	public void runCreateAccount() {
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName()
		.enterPassword()
		.clickLoginButton()
		.clickCRMSFALink()
		.clickAccounts()
		.clickCreateAccountLink()
		.enteraccountName()
		.enterDescription()
		.clickCreateAccountButton()
		.viewAccount();
	}

}
