package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods{
	public MyAccountPage clickAccounts() {
		driver.findElement(By.linkText("Accounts")).click();
		return new MyAccountPage();
	}

}
