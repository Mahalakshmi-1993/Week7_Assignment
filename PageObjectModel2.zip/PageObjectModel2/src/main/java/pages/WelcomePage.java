package pages;

import org.openqa.selenium.By;

import base.ProjectSpecificMethods;

public class WelcomePage extends ProjectSpecificMethods{
	public MyHomePage clickCRMSFALink() {
		driver.findElement(By.linkText("CRM/SFA")).click();
		return new MyHomePage();
	}
	public LoginPage logout() {
		driver.findElement(By.xpath("//input[@class='decorativeSubmit']")).click();
		return new LoginPage();
	}

}
