package pages;

import base.ProjectSpecificMethods;

public class ViewAccountPage extends ProjectSpecificMethods{
	public void viewAccount() {
		System.out.println("Account is Created");
	}

}
