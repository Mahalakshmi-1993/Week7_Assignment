package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_003_LogoutFunction extends ProjectSpecificMethods{
	@Test
	public void runLogout() {
		LoginPage lp=new LoginPage();
		lp.enterUserName()
		.enterPassword()
		.clickLoginButton()
		.logout();
	}
	

}
