package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_001_LoginFunction extends ProjectSpecificMethods{
	@Test
	public void runLogin() {
       LoginPage lp=new LoginPage();
       lp.enterUserName()
       .enterPassword()
       .clickLoginButton();
	}

}
