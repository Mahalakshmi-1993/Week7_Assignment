package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

import base.ProjectSpecificMethods;

public class CreateAccountPage extends ProjectSpecificMethods{
	
	public CreateAccountPage(EdgeDriver driver) {
		this.driver=driver;
	}
	public CreateAccountPage enteraccountName(String accountName) {
		driver.findElement(By.id("accountName")).sendKeys(accountName);
		return this;
		
	}
	public CreateAccountPage enterDescription(String description) {
		driver.findElement(By.name("description")).sendKeys(description);
		return this;
		
	}
	
	public ViewAccountPage clickCreateAccountButton() {
		driver.findElement(By.xpath("//input[@class='smallSubmit']")).click();
		return new ViewAccountPage(driver);
	}

}
