package pages;

import org.openqa.selenium.edge.EdgeDriver;

import base.ProjectSpecificMethods;

public class ViewAccountPage extends ProjectSpecificMethods{
	public ViewAccountPage(EdgeDriver driver) {
		this.driver=driver;
	}
	public void viewAccount() {
		System.out.println("Account is Created");
	}

}
