package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class TC_002_CreateAccountFunctionality extends ProjectSpecificMethods{
	@BeforeTest
	public void setValue() {
		filename="CreateAccount";
	}
	@Test(dataProvider="fetchData")
	public void runCreateAccount(String username,String password,String accountName,String description) {
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCRMSFALink()
		.clickAccounts()
		.clickCreateAccountLink()
		.enteraccountName(accountName)
		.enterDescription(description)
		.clickCreateAccountButton()
		.viewAccount();
	}

}
