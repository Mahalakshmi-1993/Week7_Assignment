package steps;

import org.openqa.selenium.By;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class EditAccountStepDefinition extends BaseClass{
	@When("Click on the Find Accounts link")
	public void click_on_the_find_accounts_link() {
	   driver.findElement(By.linkText("Find Accounts")).click();
	}
	@Given("Enter the Acc name as {string}")
	public void enterAccountName(String accName){
		driver.findElement(By.xpath("(//input[@name='accountName'])[2]")).sendKeys(accName);
	}
	@When("Click on the Find Accounts Button")
	public void click_on_the_find_accounts_button() throws InterruptedException {
	Thread.sleep(3000);
	 driver.findElement(By.xpath("//button[text()='Find Accounts']")).click();
	}

	@When("Click on the Account ID Link")
	public void click_on_the_account_id_link() throws InterruptedException {
	Thread.sleep(3000);
	driver.findElement(By.xpath("(//a[@class='linktext'])[4]")).click();
	}

	@When("Click on the Edit Button")
	public void clickEditButton() {
		driver.findElement(By.linkText("Edit")).click();
	}
	@Given("Enter the Local name as {string}")
	public void enterLocalName(String localName) {
		driver.findElement(By.id("groupNameLocal")).sendKeys(localName);
	}
	@When("Click on the Save Button")
	public void clickSaveButton() {
		driver.findElement(By.className("smallSubmit")).click();
	}
	@Then("It Should navigate to the Account details Page")
	public void accountDetailsPage() {
		System.out.println("It is navigated to Account Details page");

	}


}
