package steps;

import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class BaseClass{
	public static EdgeDriver driver;

}
