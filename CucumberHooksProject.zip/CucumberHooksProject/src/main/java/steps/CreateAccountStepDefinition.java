package steps;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateAccountStepDefinition extends BaseClass{
	
	@Given("Enter the username as Demosalesmanager")
	public void enter_the_username_as_demosalesmanager() {
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
		
	    
	}

	@Given("Enter the password as crmsfa")
	public void enter_the_password_as_crmsfa() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		
	}


	@When("Click on the login Button")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	
	}

	@Then("It should navigate to the next page")
	public void it_should_navigate_to_the_next_page() {
	   System.out.println("It is navigated to the next page");
	}

	@When("Click on the CRMSFA link")
	public void click_on_the_crmsfa_link() {
		driver.findElement(By.linkText("CRM/SFA")).click(); 
	}

	@When("Click on the Accounts link")
	public void click_on_the_accounts_link() {
	 driver.findElement(By.linkText("Accounts")).click();
	}

	@When("Click on the Create Account link")
	public void click_on_the_create_account_link() {
		driver.findElement(By.linkText("Create Account")).click();
	}
	

	@Given("Enter the Account name as {string}")
	public void enter_the_account_name_as_mahalakshmi(String accountName) {
		driver.findElement(By.id("accountName")).sendKeys(accountName);
	   
	}

	@Given("Enter the Description as {string}")
	public void enter_the_description_as(String description) {
		driver.findElement(By.name("description")).sendKeys(description);
	   
	}

	@When("Click on the Create Account Button")
	public void click_on_the_create_account_button() {
		driver.findElement(By.className("smallSubmit")).click();
	  
	}

	@Then("Account should be created")
	public void account_should_be_created() {
	    System.out.println("Account is created");
	}

}
