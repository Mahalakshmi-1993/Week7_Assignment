package steps;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DeleteAccountStepDefinition extends BaseClass {
	@When("click on the Deactivate Account Button")
	public void click_on_the_deactivate_account_button() {
	    driver.findElement(By.linkText("Deactivate Account")).click();
	    Alert deleteAlert=driver.switchTo().alert();
	    deleteAlert.accept();
	}

	@Then("It should navigate to the account details page")
	public void it_should_navigate_to_the_account_details_page() {
		System.out.println("Succesfuly Deleted");
	    
	}

}
