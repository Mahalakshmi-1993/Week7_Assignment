package hooks;

import java.time.Duration;

import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import steps.BaseClass;

public class HooksImplementationClass extends BaseClass{
	@Before
	public void preConditions() {
		driver=new EdgeDriver();    
		driver.get("http://leaftaps.com/opentaps");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.manage().window().maximize();	
			
		}
	@After
	public void postConditions() {
		driver.close();
	}

}
